package Funcion;

import Valor.Valor;

import java.util.List;

public interface Funcion {

    public abstract Valor llamar(List<Valor> argumentos);
}
